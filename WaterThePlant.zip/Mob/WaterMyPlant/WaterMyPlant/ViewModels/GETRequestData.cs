﻿namespace WaterMyPlant.ViewModels
{
    public class GETRequestData
    {
        public string moisturelevel { get; set; }

        public bool automode { get; set; }

        public string motorstate { get; set; }
    }
}