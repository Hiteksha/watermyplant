﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microcharts;
using SkiaSharp;
using Xamarin.Forms;

namespace WaterMyPlant.Views
{
    public partial class MyPlantPage : ContentPage
    {
        public MyPlantPage()
        {
            InitializeComponent();
        }
    }
}